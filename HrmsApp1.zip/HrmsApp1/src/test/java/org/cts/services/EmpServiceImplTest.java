package org.cts.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.atMost;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.*;

import org.cts.dao.EmpDao;
import org.cts.entities.Emp;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
@ExtendWith(MockitoExtension.class)
class EmpServiceImplTest {
	@Mock
	EmpDao dao;
	@Mock
	JdbcTemplate template;
	@InjectMocks
	EmpServiceImpl service;
	
	@Test
	void testInsertEmployee() {
		Emp emp=new Emp();
		service.insertEmployee(emp);
		service.insertEmployee(emp);
		verify(dao,atLeast(1)).insert(any(Emp.class));
		
	}
	@Test
	void testFindEmployee() {
		service.getEmpByEno(1);
		verify(dao,times(1)).findEmpbyEno(anyInt());
		
	}

}
