package org.cts.services;

import java.util.List;

import org.cts.dao.EmpDao;
import org.cts.entities.Emp;
import org.springframework.beans.factory.annotation.Autowired;

public class EmpServiceImpl implements EmpService {
	EmpDao dao;
	@Autowired
	public EmpServiceImpl(EmpDao dao) {
		super();
		this.dao = dao;
	}

	@Override
	public boolean insertEmployee(Emp e) {
		return dao.insert(e);
	}

	@Override
	public Emp getEmpByEno(int eno) {
		return dao.findEmpbyEno(eno);
	}

	@Override
	public List<Emp> getEmployees() {
		return dao.getAll();
	}

	@Override
	public boolean deleteEmployee(int eno) {
		return dao.delete(eno);
	}

}
