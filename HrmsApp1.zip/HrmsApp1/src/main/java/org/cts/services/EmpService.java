package org.cts.services;

import java.util.List;

import org.cts.entities.Emp;

public interface EmpService {
	boolean insertEmployee(Emp e);
	Emp getEmpByEno(int eno);
	List<Emp> getEmployees();
	boolean deleteEmployee(int eno);
}
