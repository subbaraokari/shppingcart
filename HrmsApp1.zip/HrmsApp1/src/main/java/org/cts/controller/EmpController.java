package org.cts.controller;

import javax.servlet.http.HttpServletRequest;

import org.cts.dao.EmpDao;
import org.cts.entities.Emp;
import org.cts.services.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class EmpController {
	EmpService service;
	@Autowired
	public EmpController(EmpService service) {
		super();
		this.service = service;
	}
	@GetMapping("/")
	public String showHome() {
		return "home";
		
	}
	@GetMapping("/show")
	public String showForm() {
		return "emp-form";
	}
	@PostMapping("/processForm")
	public String processForm(HttpServletRequest request,Model model) {
		int eno=Integer.parseInt(request.getParameter("eno"));
		String name=request.getParameter("name");
		String address=request.getParameter("address");
		Emp e=new Emp(eno, name, address);
		boolean b=service.insertEmployee(e);
		if(b)
		{
			model.addAttribute("msg", "Successfully inserted");
		}
		return "emp-form";
	}
}
