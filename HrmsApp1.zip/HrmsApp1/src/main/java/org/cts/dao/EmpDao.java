package org.cts.dao;

import java.util.List;
import java.util.Optional;

import org.cts.entities.Emp;

public interface EmpDao {
	boolean insert(Emp e);
	Emp findEmpbyEno(int eno);
	List<Emp> getAll();
	boolean delete(int eno);
}
