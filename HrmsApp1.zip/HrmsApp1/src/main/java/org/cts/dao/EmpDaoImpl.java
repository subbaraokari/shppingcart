package org.cts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.cts.entities.Emp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
@Repository
public class EmpDaoImpl implements EmpDao {
	JdbcTemplate template;
	@Autowired
	public EmpDaoImpl(JdbcTemplate template) {
		super();
		this.template = template;
	}

	@Override
	public boolean insert(Emp e) {
		boolean b=false;
		int i=template.update("insert into emp values(?,?,?)", e.getEno(),e.getName(),e.getAddress());
		if(i>0)
			b=true;
		return b;
	}

	@Override
	public Emp findEmpbyEno(int eno) {
		List<Emp> emps=template.query("select * from emp where eno=?", new Integer[] {eno}, new RowMapper<Emp>() {
			Emp e=null;
			@Override
			public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
				e=new Emp(rs.getInt(1), rs.getString(2), rs.getString(3));
				return e;
			}
		});
		return emps.get(0);
	}

	@Override
	public List<Emp> getAll() {
		List<Emp> emps=template.query("select * from emp", new RowMapper<Emp>() {
			Emp e=null;
			@Override
			public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
				e=new Emp(rs.getInt(1), rs.getString(2), rs.getString(3));
				return e;
			}
			
		});
		return emps;
	}

	@Override
	public boolean delete(int eno) {
		boolean b=false;
		int i=template.update("delete from emp where eno=?", eno);
		if(i>0)
			b=true;
		return b;
	}

}
