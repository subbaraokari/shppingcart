package org.cts.shoppingcart.services;

import org.cts.shoppingcart.dao.UserDao;
import org.cts.shoppingcart.entity.UserEntity;
import org.cts.shoppingcart.model.UserLoginModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class UserServiceImpl implements UserService {
	private UserDao dao;
	@Autowired
	public UserServiceImpl(UserDao dao) {
		super();
		this.dao = dao;
	}

	@Override
	public boolean registerUser(UserEntity userEntity) {
		return dao.insert(userEntity);
	}
	@Override
	public boolean login(UserLoginModel user) {
		return dao.validate(user);
	}

}
