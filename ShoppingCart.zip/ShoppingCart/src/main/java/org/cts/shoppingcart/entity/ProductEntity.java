package org.cts.shoppingcart.entity;

public class ProductEntity {
	private int pid;
	private String name;
	private String description;
	private String imageUrl;
	private int price;
	public ProductEntity() {
		// TODO Auto-generated constructor stub
	}
	public ProductEntity(int pid, String name, String description, String imageUrl, int price) {
		super();
		this.pid = pid;
		this.name = name;
		this.description = description;
		this.imageUrl = imageUrl;
		this.price = price;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
}
