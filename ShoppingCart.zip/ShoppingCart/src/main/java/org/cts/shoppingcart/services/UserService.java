package org.cts.shoppingcart.services;

import org.cts.shoppingcart.entity.UserEntity;
import org.cts.shoppingcart.model.UserLoginModel;

public interface UserService {
	boolean registerUser(UserEntity userEntity);
	boolean login(UserLoginModel user);
}
