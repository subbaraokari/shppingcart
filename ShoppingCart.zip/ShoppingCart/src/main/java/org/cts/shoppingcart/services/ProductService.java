package org.cts.shoppingcart.services;

import java.util.List;

import org.cts.shoppingcart.entity.ProductEntity;

public interface ProductService {
	public List<ProductEntity> getProducts();
}	
