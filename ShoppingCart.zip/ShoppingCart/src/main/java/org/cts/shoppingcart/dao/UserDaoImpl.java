package org.cts.shoppingcart.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.cts.shoppingcart.entity.UserEntity;
import org.cts.shoppingcart.model.UserLoginModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
@Repository
public class UserDaoImpl implements UserDao {
	JdbcTemplate template;
	@Autowired
	public UserDaoImpl(JdbcTemplate template) {
		super();
		this.template = template;
	}

	@Override
	public boolean insert(UserEntity user) {
		boolean isInserted=false;
		int i=template.update("insert into users values(?,?,?,?,?)",
				user.getUid(),user.getUsername(),user.getPassword(),user.getEmail(),user.getMobile());;
				if(i>0)
					isInserted=true;
		return isInserted;
	}

	@Override
	public boolean validate(UserLoginModel user) {
		boolean isValid=false;
		List<UserEntity> users=template.query("select * from users where username=? and password=?", 
				new String[] {user.getUsername(), user.getPassword()},new RowMapper<UserEntity>() {
					UserEntity user=null;
					@Override
					public UserEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
						user=new UserEntity(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
						return user;
					}
				});
				if(users.size()>0) {
					isValid=true;
				}
		return isValid;
	}

}
