package org.cts.shoppingcart.dao;

import org.cts.shoppingcart.entity.UserEntity;
import org.cts.shoppingcart.model.UserLoginModel;

public interface UserDao {
	boolean insert(UserEntity user);
	boolean validate(UserLoginModel user);
}
