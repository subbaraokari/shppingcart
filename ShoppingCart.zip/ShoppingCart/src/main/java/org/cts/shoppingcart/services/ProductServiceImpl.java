package org.cts.shoppingcart.services;

import java.util.List;

import org.cts.shoppingcart.dao.ProductDao;
import org.cts.shoppingcart.entity.ProductEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class ProductServiceImpl implements ProductService {
	
	ProductDao productDao;
	@Autowired
	public ProductServiceImpl(ProductDao productDao) {
		super();
		this.productDao = productDao;
	}

	@Override
	public List<ProductEntity> getProducts() {
		
		return productDao.getAll();
	}

}
