package org.cts.shoppingcart.dao;

import java.util.List;

import org.cts.shoppingcart.entity.ProductEntity;

public interface ProductDao {
	List<ProductEntity> getAll();
}
