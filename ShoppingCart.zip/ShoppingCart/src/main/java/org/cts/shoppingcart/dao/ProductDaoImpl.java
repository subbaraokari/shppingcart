package org.cts.shoppingcart.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.cts.shoppingcart.entity.ProductEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
@Repository
public class ProductDaoImpl implements ProductDao {
	
	JdbcTemplate template;
	
	@Autowired
	public ProductDaoImpl(JdbcTemplate template) {
		super();
		this.template = template;
	}


	@Override
	public List<ProductEntity> getAll() {
		List<ProductEntity> products=template.query("select * from product", new RowMapper<ProductEntity>() {
			ProductEntity product=null;
			@Override
			public ProductEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
				product=new ProductEntity(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5));
				return product;
			}
			
		});
		return products;
	}

}
