package org.cts.shoppingcart.controllers;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.cts.shoppingcart.entity.UserEntity;
import org.cts.shoppingcart.model.UserLoginModel;
import org.cts.shoppingcart.services.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/user")
public class UserController {
	private UserService userService;
	
	
	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}

	@PostMapping("/register")
	public String register(@RequestParam("uid") int uid,@RequestParam("username") String username,
			@RequestParam("password") String password,
			@RequestParam("email") String email,@RequestParam("mobile") String mobile,Model model) {
		UserEntity user=new UserEntity(uid, username, password, email, mobile);
		boolean isInserted=userService.registerUser(user);
		String viewName="";
		if(isInserted) {
			model.addAttribute("msg", "inserted Successfully");
			viewName="home";
		}
	
		return viewName;
	}
	@PostMapping("/login")
	public String login(@RequestParam("username") String username,
			@RequestParam("password") String password,HttpSession session,Model model) {
		UserLoginModel user=new UserLoginModel(username, password);
		String viewname="";
		if(userService.login(user)) {
			session.setAttribute("userdata", user);
			viewname="redirect:/products";
		}
		else
		{
			viewname="home";
			model.addAttribute("msg", "invalid user");
		}
		return viewname;
	}
}
